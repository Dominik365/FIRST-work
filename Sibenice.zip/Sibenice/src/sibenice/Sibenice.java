package sibenice;


public class Sibenice {
    public static void main(String[] args) {

        Okno okno = new Okno();
        okno.setVisible(true);
    }
}
    
